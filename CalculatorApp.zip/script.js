"use strict";

const inputValue = document.querySelector("#result");
const buttonEL = document.querySelectorAll("button");

const symbol = ["/", "*", "-", "+"];

for (let i = 0; i < buttonEL.length; i++) {
  buttonEL[i].addEventListener("click", () => {
    const val = buttonEL[i].textContent;

    if (val === "CLR") {
      clearInput();
    }
    else if (val === "=") {
      calcResult();
    }
    else if (val === "DEL") {
      delInput();
    } else {
      addedInputValue(val);
    }
  });
}

function clearInput() {
  inputValue.value = "";
}

function calcResult() {
  inputValue.value = eval(inputValue.value);
}

function addedInputValue(val) {
  if (symbol.includes(val) && symbol.includes(inputValue.value.slice(-1))) {
    inputValue.value =inputValue.value.substring(0, inputValue.value.length - 1) + val;
  } else {
    if (inputValue.value[0] != "0" && !symbol.includes(inputValue.value[0])) {
      inputValue.value = inputValue.value + val;
    } else {
      inputValue.value = val;
    }
  }
}

function delInput() {
  inputValue.value = inputValue.value.slice(0, -1);
}


///////////////////////////
// const keys = document.querySelectorAll(".key");
// // const inputValue = document.querySelector("#result");

// const display_input = document.querySelector(".calc-input .input");
// const display_output = document.querySelector(".calc-input .output");

// let input = "";

// for (let i = 0; i < keys.length; i++) {
//   const value = key.dataset.key;

//   key.addEventListener("click", () => {
//     if (value == "clear") {
//       input = "";
//       display_input.innerHTML = "";
//       display_output.innerHTML = "";
//     } else if (value == "backspace") {
//       input = input.slice(0, -1);
//       display_input.innerHTML = input;
//     } else if (value == "=") {
//       let result = eval(input);

//       display_output.innerHTML = result;
//     } else {
//       input += value;
//       display_input.innerHTML = input;
//     }
//   });
// }
